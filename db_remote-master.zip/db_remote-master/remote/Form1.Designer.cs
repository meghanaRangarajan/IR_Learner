﻿namespace remote
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.one = new System.Windows.Forms.Button();
            this.info = new System.Windows.Forms.Button();
            this.power = new System.Windows.Forms.Button();
            this.nine = new System.Windows.Forms.Button();
            this.eight = new System.Windows.Forms.Button();
            this.seven = new System.Windows.Forms.Button();
            this.six = new System.Windows.Forms.Button();
            this.five = new System.Windows.Forms.Button();
            this.four = new System.Windows.Forms.Button();
            this.three = new System.Windows.Forms.Button();
            this.two = new System.Windows.Forms.Button();
            this.zero = new System.Windows.Forms.Button();
            this.mute = new System.Windows.Forms.Button();
            this.vol_up = new System.Windows.Forms.Button();
            this.back = new System.Windows.Forms.Button();
            this.ch_down = new System.Windows.Forms.Button();
            this.ch_up = new System.Windows.Forms.Button();
            this.vol_down = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.fast_forward = new System.Windows.Forms.Button();
            this.rewind = new System.Windows.Forms.Button();
            this.play = new System.Windows.Forms.Button();
            this.stop = new System.Windows.Forms.Button();
            this.record = new System.Windows.Forms.Button();
            this.pause = new System.Windows.Forms.Button();
            this.ok = new System.Windows.Forms.Button();
            this.down = new System.Windows.Forms.Button();
            this.up = new System.Windows.Forms.Button();
            this.left = new System.Windows.Forms.Button();
            this.right = new System.Windows.Forms.Button();
            this.guide = new System.Windows.Forms.Button();
            this.next = new System.Windows.Forms.Button();
            this.language = new System.Windows.Forms.Button();
            this.previous = new System.Windows.Forms.Button();
            this.blue = new System.Windows.Forms.Button();
            this.yellow = new System.Windows.Forms.Button();
            this.green = new System.Windows.Forms.Button();
            this.red = new System.Windows.Forms.Button();
            this.options = new System.Windows.Forms.Button();
            this.menu = new System.Windows.Forms.Button();
            this.source = new System.Windows.Forms.Button();
			this.close_form = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // one
            // 
            this.one.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.one.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.one.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.one.Location = new System.Drawing.Point(18, 80);
            this.one.Name = "one";
            this.one.Size = new System.Drawing.Size(71, 33);
            this.one.TabIndex = 0;
            this.one.Text = "1";
            this.one.UseVisualStyleBackColor = false;
            this.one.Click += new System.EventHandler(this.one_Click);
			// 
            // one
            // 
            this.close_form.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.close_form.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.close_form.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.close_form.Location = new System.Drawing.Point(18,625);
			this.close_form.Name = "close_form";
			this.close_form.Size = new System.Drawing.Size(250, 33);
			this.close_form.TabIndex = 0;
			this.close_form.Text = "close remote";
			this.close_form.UseVisualStyleBackColor = false;
			this.close_form.Click += new System.EventHandler(this.close_form_Click);
            // 
            // info
            //
            this.info.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.info.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.info.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.info.Location = new System.Drawing.Point(109, 31);
            this.info.Name = "info";
            this.info.Size = new System.Drawing.Size(71, 33);
            this.info.TabIndex = 1;
            this.info.Text = "info";
            this.info.UseVisualStyleBackColor = false;
            this.info.Click += new System.EventHandler(this.info_Click);
            // 
            // power
            // 
            this.power.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.power.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.power.ForeColor = System.Drawing.Color.Red;
            this.power.Location = new System.Drawing.Point(18, 31);
            this.power.Name = "power";
            this.power.Size = new System.Drawing.Size(71, 33);
            this.power.TabIndex = 2;
            this.power.Text = "power";
            this.power.UseVisualStyleBackColor = false;
            this.power.Click += new System.EventHandler(this.power_Click);
            // 
            // nine
            // 
            this.nine.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.nine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nine.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.nine.Location = new System.Drawing.Point(196, 177);
            this.nine.Name = "nine";
            this.nine.Size = new System.Drawing.Size(71, 33);
            this.nine.TabIndex = 3;
            this.nine.Text = "9";
            this.nine.UseVisualStyleBackColor = false;
            this.nine.Click += new System.EventHandler(this.nine_Click);
            // 
            // eight
            // 
            this.eight.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.eight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.eight.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.eight.Location = new System.Drawing.Point(109, 177);
            this.eight.Name = "eight";
            this.eight.Size = new System.Drawing.Size(71, 33);
            this.eight.TabIndex = 4;
            this.eight.Text = "8";
            this.eight.UseVisualStyleBackColor = false;
            this.eight.Click += new System.EventHandler(this.eight_Click);
            // 
            // seven
            // 
            this.seven.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.seven.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.seven.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.seven.Location = new System.Drawing.Point(18, 177);
            this.seven.Name = "seven";
            this.seven.Size = new System.Drawing.Size(71, 33);
            this.seven.TabIndex = 5;
            this.seven.Text = "7";
            this.seven.UseVisualStyleBackColor = false;
            this.seven.Click += new System.EventHandler(this.seven_Click);
            // 
            // six
            // 
            this.six.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.six.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.six.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.six.Location = new System.Drawing.Point(196, 129);
            this.six.Name = "six";
            this.six.Size = new System.Drawing.Size(71, 33);
            this.six.TabIndex = 6;
            this.six.Text = "6";
            this.six.UseVisualStyleBackColor = false;
            this.six.Click += new System.EventHandler(this.six_Click);
            // 
            // five
            // 
            this.five.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.five.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.five.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.five.Location = new System.Drawing.Point(109, 129);
            this.five.Name = "five";
            this.five.Size = new System.Drawing.Size(71, 33);
            this.five.TabIndex = 7;
            this.five.Text = "5";
            this.five.UseVisualStyleBackColor = false;
            this.five.Click += new System.EventHandler(this.five_Click);
            // 
            // four
            // 
            this.four.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.four.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.four.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.four.Location = new System.Drawing.Point(18, 129);
            this.four.Name = "four";
            this.four.Size = new System.Drawing.Size(71, 33);
            this.four.TabIndex = 8;
            this.four.Text = "4";
            this.four.UseVisualStyleBackColor = false;
            this.four.Click += new System.EventHandler(this.four_Click);
            // 
            // three
            // 
            this.three.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.three.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.three.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.three.Location = new System.Drawing.Point(196, 80);
            this.three.Name = "three";
            this.three.Size = new System.Drawing.Size(71, 33);
            this.three.TabIndex = 9;
            this.three.Text = "3";
            this.three.UseVisualStyleBackColor = false;
            this.three.Click += new System.EventHandler(this.three_Click);
            // 
            // two
            // 
            this.two.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.two.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.two.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.two.Location = new System.Drawing.Point(109, 80);
            this.two.Name = "two";
            this.two.Size = new System.Drawing.Size(71, 33);
            this.two.TabIndex = 10;
            this.two.Text = "2";
            this.two.UseVisualStyleBackColor = false;
            this.two.Click += new System.EventHandler(this.two_Click);
            // 
            // zero
            // 
            this.zero.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.zero.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.zero.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.zero.Location = new System.Drawing.Point(109, 223);
            this.zero.Name = "zero";
            this.zero.Size = new System.Drawing.Size(71, 33);
            this.zero.TabIndex = 11;
            this.zero.Text = "0";
            this.zero.UseVisualStyleBackColor = false;
            this.zero.Click += new System.EventHandler(this.zero_Click);
            // 
            // mute
            // 
			this.mute.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.mute.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mute.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.mute.Location = new System.Drawing.Point(196, 31);
            this.mute.Name = "mute";
            this.mute.Size = new System.Drawing.Size(71, 33);
            this.mute.TabIndex = 12;
            this.mute.Text = "mute";
            this.mute.UseVisualStyleBackColor = false;
            this.mute.Click += new System.EventHandler(this.mute_Click);
            // 
            // vol_up
            // 
            this.vol_up.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.vol_up.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.vol_up.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.vol_up.Location = new System.Drawing.Point(18, 223);
            this.vol_up.Name = "vol_up";
            this.vol_up.Size = new System.Drawing.Size(52, 43);
            this.vol_up.TabIndex = 13;
            this.vol_up.Text = "vol up";
            this.vol_up.UseVisualStyleBackColor = false;
            this.vol_up.Click += new System.EventHandler(this.vol_up_Click);
            // 
            // back
            // 
            this.back.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.back.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.back.Location = new System.Drawing.Point(109, 262);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(71, 24);
            this.back.TabIndex = 14;
            this.back.Text = "back";
            this.back.UseVisualStyleBackColor = false;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // ch_down
            // 
            this.ch_down.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.ch_down.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ch_down.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.ch_down.Location = new System.Drawing.Point(215, 272);
            this.ch_down.Name = "ch_down";
            this.ch_down.Size = new System.Drawing.Size(52, 43);
            this.ch_down.TabIndex = 15;
            this.ch_down.Text = "ch down";
            this.ch_down.UseVisualStyleBackColor = false;
            this.ch_down.Click += new System.EventHandler(this.ch_down_Click);
            // 
            // ch_up
            // 
            this.ch_up.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.ch_up.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ch_up.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.ch_up.Location = new System.Drawing.Point(215, 223);
            this.ch_up.Name = "ch_up";
            this.ch_up.Size = new System.Drawing.Size(52, 43);
            this.ch_up.TabIndex = 16;
            this.ch_up.Text = "ch up";
            this.ch_up.UseVisualStyleBackColor = false;
            this.ch_up.Click += new System.EventHandler(this.ch_up_Click);
            // 
            // vol_down
            // 
            this.vol_down.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.vol_down.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.vol_down.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.vol_down.Location = new System.Drawing.Point(18, 272);
            this.vol_down.Name = "vol_down";
            this.vol_down.Size = new System.Drawing.Size(52, 43);
            this.vol_down.TabIndex = 17;
            this.vol_down.Text = "vol down";
            this.vol_down.UseVisualStyleBackColor = false;
            this.vol_down.Click += new System.EventHandler(this.vol_down_Click);
            // 
            // exit
            // 
            this.exit.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exit.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.exit.Location = new System.Drawing.Point(109, 292);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(71, 24);
            this.exit.TabIndex = 18;
            this.exit.Text = "exit";
            this.exit.UseVisualStyleBackColor = false;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // fast_forward
            // 
            this.fast_forward.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.fast_forward.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fast_forward.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.fast_forward.Location = new System.Drawing.Point(196, 553);
            this.fast_forward.Name = "fast_forward";
            this.fast_forward.Size = new System.Drawing.Size(71, 24);
            this.fast_forward.TabIndex = 21;
            this.fast_forward.Text = ">>";
            this.fast_forward.UseVisualStyleBackColor = false;
            this.fast_forward.Click += new System.EventHandler(this.fast_forward_Click);
            // 
            // rewind
            // 
            this.rewind.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.rewind.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rewind.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.rewind.Location = new System.Drawing.Point(18, 553);
            this.rewind.Name = "rewind";
            this.rewind.Size = new System.Drawing.Size(71, 24);
            this.rewind.TabIndex = 20;
            this.rewind.Text = "<<";
            this.rewind.UseVisualStyleBackColor = false;
            this.rewind.Click += new System.EventHandler(this.rewind_Click);
            // 
            // play
            // 
            this.play.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.play.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.play.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.play.Location = new System.Drawing.Point(109, 553);
            this.play.Name = "play";
            this.play.Size = new System.Drawing.Size(71, 24);
            this.play.TabIndex = 19;
            this.play.Text = "play";
            this.play.UseVisualStyleBackColor = false;
            this.play.Click += new System.EventHandler(this.play_Click);
            // 
            // stop
            // 
            this.stop.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.stop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.stop.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.stop.Location = new System.Drawing.Point(196, 583);
            this.stop.Name = "stop";
            this.stop.Size = new System.Drawing.Size(71, 24);
            this.stop.TabIndex = 24;
            this.stop.Text = "stop";
            this.stop.UseVisualStyleBackColor = false;
            this.stop.Click += new System.EventHandler(this.stop_Click);
            // 
            // record
            // 
            this.record.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.record.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.record.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.record.Location = new System.Drawing.Point(18, 583);
            this.record.Name = "record";
            this.record.Size = new System.Drawing.Size(71, 24);
            this.record.TabIndex = 23;
            this.record.Text = "record";
            this.record.UseVisualStyleBackColor = false;
            this.record.Click += new System.EventHandler(this.record_Click);
            // 
            // pause
            // 
            this.pause.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.pause.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pause.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.pause.Location = new System.Drawing.Point(109, 583);
            this.pause.Name = "pause";
            this.pause.Size = new System.Drawing.Size(71, 24);
            this.pause.TabIndex = 22;
            this.pause.Text = "pause";
            this.pause.UseVisualStyleBackColor = false;
            this.pause.Click += new System.EventHandler(this.pause_Click);
            // 
            // ok
            // 
            this.ok.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.ok.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ok.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.ok.Location = new System.Drawing.Point(122, 413);
            this.ok.Name = "ok";
            this.ok.Size = new System.Drawing.Size(45, 22);
            this.ok.TabIndex = 25;
            this.ok.Text = "OK";
            this.ok.UseVisualStyleBackColor = false;
            this.ok.Click += new System.EventHandler(this.ok_Click);
            // 
            // down
            // 
            this.down.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.down.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.down.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.down.Location = new System.Drawing.Point(122, 441);
            this.down.Name = "down";
            this.down.Size = new System.Drawing.Size(45, 22);
            this.down.TabIndex = 26;
            this.down.Text = "down";
            this.down.UseVisualStyleBackColor = false;
            this.down.Click += new System.EventHandler(this.down_Click);
            // 
            // up
            // 
            this.up.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.up.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.up.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.up.Location = new System.Drawing.Point(122, 385);
            this.up.Name = "up";
            this.up.Size = new System.Drawing.Size(45, 22);
            this.up.TabIndex = 27;
            this.up.Text = "up";
            this.up.UseVisualStyleBackColor = false;
            this.up.Click += new System.EventHandler(this.up_Click);
            // 
            // left
            // 
            this.left.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.left.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.left.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.left.Location = new System.Drawing.Point(98, 385);
            this.left.Name = "left";
            this.left.Size = new System.Drawing.Size(18, 78);
            this.left.TabIndex = 28;
            this.left.Text = "lef t";
            this.left.UseVisualStyleBackColor = false;
            this.left.Click += new System.EventHandler(this.left_Click);
            // 
            // right
            // 
            this.right.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.right.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.right.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.right.Location = new System.Drawing.Point(173, 387);
            this.right.Name = "right";
            this.right.Size = new System.Drawing.Size(18, 76);
            this.right.TabIndex = 29;
            this.right.Text = "r ight";
            this.right.UseVisualStyleBackColor = false;
            this.right.Click += new System.EventHandler(this.right_Click);
            // 
            // guide
            // 
            this.guide.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.guide.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.guide.Location = new System.Drawing.Point(204, 424);
            this.guide.Name = "guide";
            this.guide.Size = new System.Drawing.Size(63, 43);
            this.guide.TabIndex = 31;
            this.guide.Text = "guide";
            this.guide.UseVisualStyleBackColor = true;
            this.guide.Click += new System.EventHandler(this.guide_Click);
            // 
            // next
            // 
            this.next.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.next.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.next.Location = new System.Drawing.Point(204, 375);
            this.next.Name = "next";
            this.next.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.next.Size = new System.Drawing.Size(63, 43);
            this.next.TabIndex = 30;
            this.next.Text = "next";
            this.next.UseVisualStyleBackColor = true;
            this.next.Click += new System.EventHandler(this.next_Click);
            // 
            // language
            // 
            this.language.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.language.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.language.Location = new System.Drawing.Point(18, 424);
            this.language.Name = "language";
            this.language.Size = new System.Drawing.Size(63, 43);
            this.language.TabIndex = 33;
            this.language.Text = "language";
            this.language.UseVisualStyleBackColor = true;
            this.language.Click += new System.EventHandler(this.language_Click);
            // 
            // previous
            // 
            this.previous.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.previous.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.previous.Location = new System.Drawing.Point(18, 375);
            this.previous.Name = "previous";
            this.previous.Size = new System.Drawing.Size(63, 43);
            this.previous.TabIndex = 32;
            this.previous.Text = "previous";
            this.previous.UseVisualStyleBackColor = true;
            this.previous.Click += new System.EventHandler(this.previous_Click);
            // 
            // blue
            // 
            this.blue.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.blue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.blue.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.blue.Location = new System.Drawing.Point(226, 488);
            this.blue.Name = "blue";
            this.blue.Size = new System.Drawing.Size(41, 40);
            this.blue.TabIndex = 0;
            this.blue.UseVisualStyleBackColor = false;
            this.blue.Click += new System.EventHandler(this.blue_Click);
            // 
            // yellow
            // 
            this.yellow.BackColor = System.Drawing.Color.Yellow;
            this.yellow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.yellow.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.yellow.Location = new System.Drawing.Point(160, 488);
            this.yellow.Name = "yellow";
            this.yellow.Size = new System.Drawing.Size(41, 40);
            this.yellow.TabIndex = 34;
            this.yellow.UseVisualStyleBackColor = false;
            this.yellow.Click += new System.EventHandler(this.yellow_Click);
            // 
            // green
            // 
            this.green.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.green.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.green.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.green.Location = new System.Drawing.Point(88, 488);
            this.green.Name = "green";
            this.green.Size = new System.Drawing.Size(41, 40);
            this.green.TabIndex = 35;
            this.green.UseVisualStyleBackColor = false;
            this.green.Click += new System.EventHandler(this.green_Click);
            // 
            // red
            // 
            this.red.BackColor = System.Drawing.Color.Red;
            this.red.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.red.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.red.Location = new System.Drawing.Point(18, 488);
            this.red.Name = "red";
            this.red.Size = new System.Drawing.Size(41, 40);
            this.red.TabIndex = 36;
            this.red.UseVisualStyleBackColor = false;
            this.red.Click += new System.EventHandler(this.red_Click);
            // 
            // options
            // 
            this.options.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.options.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.options.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.options.Location = new System.Drawing.Point(196, 339);
            this.options.Name = "options";
            this.options.Size = new System.Drawing.Size(71, 24);
            this.options.TabIndex = 39;
            this.options.Text = "options";
            this.options.UseVisualStyleBackColor = false;
            this.options.Click += new System.EventHandler(this.options_Click);
            // 
            // menu
            // 
            this.menu.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.menu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.menu.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.menu.Location = new System.Drawing.Point(18, 339);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(71, 24);
            this.menu.TabIndex = 38;
            this.menu.Text = "menu";
            this.menu.UseVisualStyleBackColor = false;
            this.menu.Click += new System.EventHandler(this.menu_Click);
            // 
            // source
            // 
            this.source.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.source.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.source.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.source.Location = new System.Drawing.Point(109, 339);
            this.source.Name = "source";
            this.source.Size = new System.Drawing.Size(71, 24);
            this.source.TabIndex = 37;
            this.source.Text = "source";
            this.source.UseVisualStyleBackColor = false;
            this.source.Click += new System.EventHandler(this.source_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(294, 670);
            this.Controls.Add(this.options);
            this.Controls.Add(this.menu);
            this.Controls.Add(this.source);
            this.Controls.Add(this.red);
            this.Controls.Add(this.green);
            this.Controls.Add(this.yellow);
            this.Controls.Add(this.blue);
            this.Controls.Add(this.language);
            this.Controls.Add(this.previous);
            this.Controls.Add(this.guide);
            this.Controls.Add(this.next);
            this.Controls.Add(this.right);
            this.Controls.Add(this.left);
            this.Controls.Add(this.up);
            this.Controls.Add(this.down);
            this.Controls.Add(this.ok);
            this.Controls.Add(this.stop);
            this.Controls.Add(this.record);
            this.Controls.Add(this.pause);
            this.Controls.Add(this.fast_forward);
            this.Controls.Add(this.rewind);
            this.Controls.Add(this.play);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.vol_down);
            this.Controls.Add(this.ch_up);
            this.Controls.Add(this.ch_down);
            this.Controls.Add(this.back);
            this.Controls.Add(this.vol_up);
            this.Controls.Add(this.mute);
            this.Controls.Add(this.zero);
            this.Controls.Add(this.two);
            this.Controls.Add(this.three);
            this.Controls.Add(this.four);
            this.Controls.Add(this.five);
            this.Controls.Add(this.six);
            this.Controls.Add(this.seven);
            this.Controls.Add(this.eight);
            this.Controls.Add(this.nine);
            this.Controls.Add(this.power);
            this.Controls.Add(this.info);
            this.Controls.Add(this.one);
			this.Controls.Add(this.close_form);
            this.Name = "Remote";
			this.Text = "Remote";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button one;
		private System.Windows.Forms.Button close_form;
        private System.Windows.Forms.Button info;
        private System.Windows.Forms.Button power;
        private System.Windows.Forms.Button nine;
        private System.Windows.Forms.Button eight;
        private System.Windows.Forms.Button seven;
        private System.Windows.Forms.Button six;
        private System.Windows.Forms.Button five;
        private System.Windows.Forms.Button four;
        private System.Windows.Forms.Button three;
        private System.Windows.Forms.Button two;
        private System.Windows.Forms.Button zero;
        private System.Windows.Forms.Button mute;
        private System.Windows.Forms.Button vol_up;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.Button ch_down;
        private System.Windows.Forms.Button ch_up;
        private System.Windows.Forms.Button vol_down;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Button fast_forward;
        private System.Windows.Forms.Button rewind;
        private System.Windows.Forms.Button play;
        private System.Windows.Forms.Button stop;
        private System.Windows.Forms.Button record;
        private System.Windows.Forms.Button pause;
        private System.Windows.Forms.Button ok;
        private System.Windows.Forms.Button down;
        private System.Windows.Forms.Button up;
        private System.Windows.Forms.Button left;
        private System.Windows.Forms.Button right;
        private System.Windows.Forms.Button guide;
        private System.Windows.Forms.Button next;
        private System.Windows.Forms.Button language;
        private System.Windows.Forms.Button previous;
        private System.Windows.Forms.Button blue;
        private System.Windows.Forms.Button yellow;
        private System.Windows.Forms.Button green;
        private System.Windows.Forms.Button red;
        private System.Windows.Forms.Button options;
        private System.Windows.Forms.Button menu;
        private System.Windows.Forms.Button source;
    }
}

